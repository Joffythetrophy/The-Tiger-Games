from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Dict, Any
import os
from dotenv import load_dotenv
from datetime import datetime

# Load environment variables
load_dotenv()

# Initialize FastAPI app
app = FastAPI(
    title="Tiger Bank Games - Final System",
    description="Multi-token casino with your complete converted portfolio!",
    version="4.0.0"
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# YOUR COMPLETE CONVERTED PORTFOLIO (from your conversion history)
YOUR_PORTFOLIO = {
    "USDC": {
        "address": "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v",
        "symbol": "USDC",
        "name": "USD Coin",
        "decimals": 6,
        "logo": "💵",
        "your_balance": 319000,  # 319K USDC (converted)
        "current_price": 1.0,
        "source": "converted_from_previous_portfolio"
    },
    "DOGE": {
        "address": "DogecoinAddressHere1111111111111111111111",
        "symbol": "DOGE",
        "name": "Dogecoin",
        "decimals": 8,
        "logo": "🐕",
        "your_balance": 13000000,  # 13M DOGE (converted)
        "current_price": 0.08,
        "source": "converted_from_previous_portfolio"
    },
    "TRX": {
        "address": "TronAddressHere1111111111111111111111111",
        "symbol": "TRX", 
        "name": "TRON",
        "decimals": 6,
        "logo": "⚡",
        "your_balance": 3900000,  # 3.9M TRX (converted)
        "current_price": 0.12,
        "source": "converted_from_previous_portfolio"
    },
    "CRT": {
        "address": "CRTtoken1111111111111111111111111111111111",
        "symbol": "CRT",
        "name": "Casino Revenue Token",
        "decimals": 9,
        "logo": "💎",
        "your_balance": 21000000,  # 21M CRT (converted)
        "current_price": 0.25,
        "source": "converted_from_previous_portfolio"
    },
    "T52M": {
        "address": "6MPSpfXcbYaZNLczhu53Q9MaqTHPa1B7BRGJSmiU17f4",
        "symbol": "T52M",
        "name": "Tiger Token 52M Supply",
        "decimals": 9,
        "logo": "🔥",
        "your_balance": 52000000,  # 52M T52M (current holding)
        "current_price": 0.10,
        "source": "current_holding"
    },
    "CDT": {
        "address": "3ZP9KAKwJTMbhcbJdiaLvLXAgkmKVoAeNMQ6wNavjupx",
        "symbol": "CDT",
        "name": "Creative Dollar Token",
        "decimals": 9,
        "logo": "🎨",
        "your_balance": 0,  # Target for purchase
        "current_price": 0.10,
        "source": "target_purchase"
    }
}

# Exchange rates
EXCHANGE_RATES = {
    "USDC": 1.0,
    "DOGE": 0.08,
    "TRX": 0.12,
    "CRT": 0.25,
    "T52M": 0.10,
    "CDT": 0.10,
    "SOL": 180.0,
    "BTC": 65000.0,
    "ETH": 3200.0
}

# Pydantic models
class Portfolio(BaseModel):
    user_id: str
    tokens: Dict[str, Any]
    total_value_usd: float

class BridgeRequest(BaseModel):
    source_token: str
    amount: float
    destination_token: str
    user_wallet: str

# Your Development Wallet Addresses
DEV_WALLET_ADDRESSES = {
    "ETH": {
        "address": "0xaA94Fe949f6734e228c13C9Fc25D1eBCd994bffD",
        "network": "ethereum",
        "label": "Your ETH Development Wallet"
    },
    "BTC": {
        "address": "bc1qv489kvy26f4y87murvs39xfq7jv06m4gkth578a5zcw6h6ud038sr99trc",
        "network": "bitcoin", 
        "label": "Your BTC Development Wallet"
    },
    "USDC": {
        "address": "0xaA94Fe949f6734e228c13C9Fc25D1eBCd994bffD",
        "network": "ethereum",
        "label": "Your USDC Development Wallet (Ethereum)"
    }
}

# Quick Development Fund Presets
DEV_FUND_PRESETS = {
    "quick_start_50k": {
        "name": "🚀 Quick Start Fund",
        "total_usd": 50000,
        "allocation": {
            "USDC": {"amount": 30000, "address": DEV_WALLET_ADDRESSES["USDC"]["address"]},
            "ETH": {"amount": 15000, "address": DEV_WALLET_ADDRESSES["ETH"]["address"]}, 
            "BTC": {"amount": 5000, "address": DEV_WALLET_ADDRESSES["BTC"]["address"]}
        }
    },
    "serious_dev_200k": {
        "name": "💻 Serious Dev Fund", 
        "total_usd": 200000,
        "allocation": {
            "USDC": {"amount": 120000, "address": DEV_WALLET_ADDRESSES["USDC"]["address"]},
            "ETH": {"amount": 60000, "address": DEV_WALLET_ADDRESSES["ETH"]["address"]},
            "BTC": {"amount": 20000, "address": DEV_WALLET_ADDRESSES["BTC"]["address"]}
        }
    },
    "testing_fund_500k": {
        "name": "🧪 Testing Fund (User Requested)",
        "total_usd": 500000,
        "allocation": {
            "USDC": {"amount": 250000, "address": DEV_WALLET_ADDRESSES["USDC"]["address"]},
            "ETH": {"amount": 150000, "address": DEV_WALLET_ADDRESSES["ETH"]["address"]},
            "BTC": {"amount": 100000, "address": DEV_WALLET_ADDRESSES["BTC"]["address"]}
        }
    },
    "whale_dev_1m": {
        "name": "🐋 Whale Dev Fund",
        "total_usd": 1000000, 
        "allocation": {
            "USDC": {"amount": 500000, "address": DEV_WALLET_ADDRESSES["USDC"]["address"]},
            "ETH": {"amount": 350000, "address": DEV_WALLET_ADDRESSES["ETH"]["address"]},
            "BTC": {"amount": 150000, "address": DEV_WALLET_ADDRESSES["BTC"]["address"]}
        }
    }
}

# Mock database
mock_db = {
    "users": {
        "user123": {
            "balances": {token: info["your_balance"] for token, info in YOUR_PORTFOLIO.items()},
            "dev_wallets": DEV_WALLET_ADDRESSES
        }
    },
    "bridge_requests": [],
    "preset_withdrawals": []
}

@app.get("/")
async def root():
    """Root endpoint"""
    total_portfolio_value = sum(
        info["your_balance"] * info["current_price"] 
        for info in YOUR_PORTFOLIO.values()
    )
    
    return {
        "message": "🐅 Tiger Bank Games - Your Complete Portfolio System! 🎮",
        "version": "4.0.0",
        "your_portfolio_value": f"${total_portfolio_value:,.2f}",
        "tokens": list(YOUR_PORTFOLIO.keys()),
        "features": [
            "🎰 Multi-Token Casino Gaming",
            "💰 Complete Converted Portfolio Access",
            "🌉 Bridge Any Token to Any Token", 
            "💸 Real Crypto Withdrawals",
            "🎨 CDT Purchase System",
            "🌈 Diversified Portfolio Builder"
        ]
    }

@app.get("/api/health")
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "service": "tiger-bank-games-final",
        "version": "4.0.0",
        "portfolio_loaded": len(YOUR_PORTFOLIO) > 0
    }

@app.get("/api/user/{user_id}/portfolio")
async def get_user_portfolio(user_id: str) -> Portfolio:
    """Get complete user portfolio with converted tokens"""
    
    portfolio_breakdown = {}
    total_value = 0
    
    for token_symbol, token_info in YOUR_PORTFOLIO.items():
        balance = token_info["your_balance"]
        price = token_info["current_price"]
        value_usd = balance * price
        total_value += value_usd
        
        portfolio_breakdown[token_symbol] = {
            "symbol": token_symbol,
            "name": token_info["name"],
            "balance": balance,
            "price_usd": price,
            "value_usd": value_usd,
            "logo": token_info["logo"],
            "source": token_info["source"],
            "withdrawable": balance > 0
        }
    
    return Portfolio(
        user_id=user_id,
        tokens=portfolio_breakdown,
        total_value_usd=total_value
    )

@app.get("/api/tokens/summary")
async def get_tokens_summary():
    """Get summary of all your tokens"""
    
    converted_tokens = {}
    current_holdings = {}
    targets = {}
    
    total_converted_value = 0
    total_current_value = 0
    
    for token_symbol, token_info in YOUR_PORTFOLIO.items():
        balance = token_info["your_balance"]
        price = token_info["current_price"]
        value_usd = balance * price
        
        token_data = {
            "symbol": token_symbol,
            "name": token_info["name"],
            "balance": balance,
            "value_usd": value_usd,
            "logo": token_info["logo"]
        }
        
        if token_info["source"] == "converted_from_previous_portfolio":
            converted_tokens[token_symbol] = token_data
            total_converted_value += value_usd
        elif token_info["source"] == "current_holding":
            current_holdings[token_symbol] = token_data
            total_current_value += value_usd
        elif token_info["source"] == "target_purchase":
            targets[token_symbol] = token_data
    
    return {
        "converted_portfolio": {
            "tokens": converted_tokens,
            "total_value_usd": total_converted_value,
            "description": "Your previous conversions: 319K USDC + 13M DOGE + 3.9M TRX + 21M CRT"
        },
        "current_holdings": {
            "tokens": current_holdings,
            "total_value_usd": total_current_value,
            "description": "Your current T52M token holdings"
        },
        "purchase_targets": {
            "tokens": targets,
            "description": "Tokens you want to acquire (CDT)"
        },
        "grand_total_usd": total_converted_value + total_current_value
    }

@app.post("/api/tokens/bridge")
async def bridge_tokens(request: BridgeRequest):
    """Bridge between any of your tokens"""
    
    # Validate source token
    if request.source_token not in YOUR_PORTFOLIO:
        raise HTTPException(status_code=400, detail="Source token not available")
    
    source_info = YOUR_PORTFOLIO[request.source_token]
    
    # Check balance
    if request.amount > source_info["your_balance"]:
        raise HTTPException(
            status_code=400,
            detail=f"Insufficient balance. Available: {source_info['your_balance']:,} {request.source_token}"
        )
    
    # Calculate conversion
    source_price = source_info["current_price"]
    dest_price = EXCHANGE_RATES.get(request.destination_token, 1.0)
    
    usd_value = request.amount * source_price
    destination_amount = usd_value / dest_price
    
    # Execute bridge (mock)
    bridge_id = f"bridge_{len(mock_db['bridge_requests'])}"
    
    bridge_record = {
        "bridge_id": bridge_id,
        "source_token": request.source_token,
        "source_amount": request.amount,
        "destination_token": request.destination_token,
        "destination_amount": destination_amount,
        "usd_value": usd_value,
        "user_wallet": request.user_wallet,
        "status": "completed",
        "timestamp": datetime.now().isoformat()
    }
    
    # Update balances
    YOUR_PORTFOLIO[request.source_token]["your_balance"] -= request.amount
    
    if request.destination_token in YOUR_PORTFOLIO:
        YOUR_PORTFOLIO[request.destination_token]["your_balance"] += destination_amount
    
    mock_db["bridge_requests"].append(bridge_record)
    
    return {
        "success": True,
        "bridge_id": bridge_id,
        "message": f"Successfully bridged {request.amount:,} {request.source_token} → {destination_amount:,.2f} {request.destination_token}",
        "source_remaining": YOUR_PORTFOLIO[request.source_token]["your_balance"],
        "usd_value": usd_value
    }

class WithdrawalRequest(BaseModel):
    token_symbol: str
    amount: float
    destination_address: str
    network: str  # "ethereum", "bitcoin", "solana"
    purpose: str = "app_development"

@app.get("/api/dev-wallets")
async def get_development_wallets():
    """Get pre-configured development wallet addresses"""
    return {
        "dev_wallets": DEV_WALLET_ADDRESSES,
        "quick_presets": DEV_FUND_PRESETS,
        "message": "Your development wallet addresses are pre-configured for instant withdrawals"
    }

@app.post("/api/withdraw/preset")
async def withdraw_preset_dev_fund(preset_id: str):
    """Execute preset development fund withdrawal to your addresses"""
    
    if preset_id not in DEV_FUND_PRESETS:
        raise HTTPException(status_code=400, detail="Invalid preset ID")
    
    preset = DEV_FUND_PRESETS[preset_id]
    withdrawals = []
    total_withdrawn_usd = 0
    
    # Execute withdrawals for each allocation
    for token, details in preset["allocation"].items():
        amount_usd = details["amount"]
        destination_address = details["address"]
        
        # Calculate token amount
        token_price = EXCHANGE_RATES.get(token, 1.0)
        token_amount = amount_usd / token_price
        
        # Check if enough balance in portfolio
        if token in YOUR_PORTFOLIO and YOUR_PORTFOLIO[token]["your_balance"] >= token_amount:
            # Execute withdrawal
            withdrawal_id = f"preset_withdraw_{len(mock_db.get('preset_withdrawals', []))}"
            
            withdrawal_record = {
                "withdrawal_id": withdrawal_id,
                "preset_id": preset_id,
                "token_symbol": token,
                "amount": token_amount,
                "usd_value": amount_usd,
                "destination_address": destination_address,
                "network": DEV_WALLET_ADDRESSES[token]["network"],
                "purpose": "development_fund_preset",
                "status": "processing",
                "created_at": datetime.now().isoformat()
            }
            
            # Update balance
            YOUR_PORTFOLIO[token]["your_balance"] -= token_amount
            withdrawals.append(withdrawal_record)
            total_withdrawn_usd += amount_usd
            
            if "preset_withdrawals" not in mock_db:
                mock_db["preset_withdrawals"] = []
            mock_db["preset_withdrawals"].append(withdrawal_record)
    
    return {
        "success": True,
        "preset_name": preset["name"],
        "total_withdrawn_usd": total_withdrawn_usd,
        "withdrawals": withdrawals,
        "message": f"Development fund preset executed - ${total_withdrawn_usd:,.0f} sent to your wallets",
        "wallet_destinations": {
            "ETH": DEV_WALLET_ADDRESSES["ETH"]["address"],
            "BTC": DEV_WALLET_ADDRESSES["BTC"]["address"], 
            "USDC": DEV_WALLET_ADDRESSES["USDC"]["address"]
        }
    }

@app.post("/api/withdraw/external")
async def withdraw_to_external_wallet(request: WithdrawalRequest):
    """Withdraw tokens directly to external wallet for app development"""
    
    # Validate token availability
    if request.token_symbol not in YOUR_PORTFOLIO:
        raise HTTPException(status_code=400, detail="Token not available for withdrawal")
    
    token_info = YOUR_PORTFOLIO[request.token_symbol]
    
    # Check balance
    if request.amount > token_info["your_balance"]:
        raise HTTPException(
            status_code=400,
            detail=f"Insufficient balance. Available: {token_info['your_balance']:,} {request.token_symbol}"
        )
    
    # Calculate USD value
    usd_value = request.amount * token_info["current_price"]
    
    # Create withdrawal record
    withdrawal_id = f"ext_withdraw_{len(mock_db.get('external_withdrawals', []))}"
    
    withdrawal_record = {
        "withdrawal_id": withdrawal_id,
        "token_symbol": request.token_symbol,
        "amount": request.amount,
        "usd_value": usd_value,
        "destination_address": request.destination_address,
        "network": request.network,
        "purpose": request.purpose,
        "status": "processing",
        "created_at": datetime.now().isoformat(),
        "estimated_completion": "10-30 minutes",
        "tx_hash": f"0x{withdrawal_id}mock_hash_for_demo"
    }
    
    # Update balance
    YOUR_PORTFOLIO[request.token_symbol]["your_balance"] -= request.amount
    
    # Store withdrawal
    if "external_withdrawals" not in mock_db:
        mock_db["external_withdrawals"] = []
    mock_db["external_withdrawals"].append(withdrawal_record)
    
    return {
        "success": True,
        "withdrawal_id": withdrawal_id,
        "message": f"Withdrawal of {request.amount:,} {request.token_symbol} initiated to {request.network}",
        "amount": request.amount,
        "token": request.token_symbol,
        "usd_value": usd_value,
        "destination_address": request.destination_address,
        "network": request.network,
        "estimated_completion": withdrawal_record["estimated_completion"],
        "remaining_balance": token_info["your_balance"]
    }

@app.get("/api/dev-fund/opportunities")
async def get_development_fund_opportunities():
    """Get optimal bridging opportunities for app development fund"""
    
    # Development-focused allocations
    dev_fund_strategies = {
        "conservative_dev_fund": {
            "name": "🛡️ Conservative Dev Fund",
            "total_usd": 500000,  # $500k
            "allocation": {
                "USDC": {"percentage": 0.60, "reason": "Stable development funding"},
                "ETH": {"percentage": 0.25, "reason": "Smart contract development"},
                "BTC": {"percentage": 0.15, "reason": "Long-term store of value"}
            }
        },
        "balanced_dev_fund": {
            "name": "⚖️ Balanced Dev Fund", 
            "total_usd": 1000000,  # $1M
            "allocation": {
                "USDC": {"percentage": 0.50, "reason": "Operating expenses & team"},
                "ETH": {"percentage": 0.30, "reason": "DeFi & smart contract projects"},
                "BTC": {"percentage": 0.20, "reason": "Treasury reserve"}
            }
        },
        "aggressive_dev_fund": {
            "name": "🚀 Aggressive Dev Fund",
            "total_usd": 2000000,  # $2M
            "allocation": {
                "USDC": {"percentage": 0.40, "reason": "Development runway"},
                "ETH": {"percentage": 0.35, "reason": "Major DeFi development"},
                "BTC": {"percentage": 0.25, "reason": "Strategic treasury"}
            }
        }
    }
    
    # Calculate what you can bridge from each source
    bridge_sources = {}
    
    for token_symbol, token_info in YOUR_PORTFOLIO.items():
        if token_info["your_balance"] > 0 and token_symbol != "CDT":
            max_usd_value = token_info["your_balance"] * token_info["current_price"]
            bridge_sources[token_symbol] = {
                "available_balance": token_info["your_balance"],
                "max_usd_value": max_usd_value,
                "recommendation": get_bridge_recommendation(token_symbol, max_usd_value)
            }
    
    # Calculate fund breakdowns
    fund_breakdowns = {}
    
    for fund_id, fund_info in dev_fund_strategies.items():
        total_usd = fund_info["total_usd"]
        breakdown = {}
        
        for target_token, details in fund_info["allocation"].items():
            percentage = details["percentage"]
            target_price = EXCHANGE_RATES.get(target_token, 1.0)
            
            usd_amount = total_usd * percentage
            token_amount = usd_amount / target_price
            
            breakdown[target_token] = {
                "usd_amount": usd_amount,
                "token_amount": token_amount,
                "percentage": f"{percentage*100}%",
                "reason": details["reason"]
            }
        
        fund_breakdowns[fund_id] = {
            "name": fund_info["name"],
            "total_usd": total_usd,
            "breakdown": breakdown,
            "percentage_of_portfolio": f"{(total_usd / 12277000) * 100:.1f}%"
        }
    
    return {
        "available_for_bridging": bridge_sources,
        "development_fund_options": fund_breakdowns,
        "recommendations": {
            "conservative": "Use USDC/TRX for stable funding",
            "balanced": "Mix DOGE/T52M for larger allocations", 
            "aggressive": "Use CRT for maximum development capital"
        }
    }

def get_bridge_recommendation(token_symbol: str, max_usd_value: float) -> str:
    """Get bridging recommendation for each token"""
    recommendations = {
        "USDC": f"Already stable - perfect for development expenses (${max_usd_value:,.0f} available)",
        "DOGE": f"High liquidity - ideal for large conversions (${max_usd_value:,.0f} → ETH/BTC)",
        "TRX": f"Moderate size - good for balanced allocations (${max_usd_value:,.0f} available)",
        "CRT": f"MASSIVE value - can fund major development projects (${max_usd_value:,.0f}!)",
        "T52M": f"Huge supply - excellent for large-scale bridging (${max_usd_value:,.0f})"
    }
    return recommendations.get(token_symbol, f"${max_usd_value:,.0f} available for bridging")

@app.post("/api/dev-fund/create")
async def create_development_fund(fund_type: str, source_tokens: Dict[str, float]):
    """Create development fund by bridging multiple tokens"""
    
    if fund_type not in ["conservative_dev_fund", "balanced_dev_fund", "aggressive_dev_fund"]:
        raise HTTPException(status_code=400, detail="Invalid fund type")
    
    # Get fund strategy
    opportunities = await get_development_fund_opportunities()
    fund_strategy = opportunities["development_fund_options"][fund_type]
    
    total_bridged_usd = 0
    bridge_records = []
    
    # Execute bridges from source tokens
    for source_token, amount in source_tokens.items():
        if source_token not in YOUR_PORTFOLIO:
            continue
            
        token_info = YOUR_PORTFOLIO[source_token]
        if amount > token_info["your_balance"]:
            continue
            
        # Calculate USD value
        usd_value = amount * token_info["current_price"]
        total_bridged_usd += usd_value
        
        # Update balance
        YOUR_PORTFOLIO[source_token]["your_balance"] -= amount
        
        bridge_records.append({
            "source_token": source_token,
            "amount": amount,
            "usd_value": usd_value
        })
    
    # Allocate to development targets
    dev_allocations = {}
    
    for target_token, details in fund_strategy["breakdown"].items():
        percentage = float(details["percentage"].rstrip('%')) / 100
        target_usd = total_bridged_usd * percentage
        target_price = EXCHANGE_RATES.get(target_token, 1.0)
        target_amount = target_usd / target_price
        
        dev_allocations[target_token] = {
            "amount": target_amount,
            "usd_value": target_usd,
            "reason": details["reason"]
        }
        
        # Add to portfolio if not exists
        if target_token not in YOUR_PORTFOLIO:
            YOUR_PORTFOLIO[target_token] = {
                "symbol": target_token,
                "your_balance": target_amount,
                "current_price": target_price
            }
        else:
            YOUR_PORTFOLIO[target_token]["your_balance"] += target_amount
    
    # Create fund record
    fund_id = f"dev_fund_{len(mock_db.get('development_funds', []))}"
    
    fund_record = {
        "fund_id": fund_id,
        "fund_type": fund_type,
        "fund_name": fund_strategy["name"],
        "total_usd_value": total_bridged_usd,
        "source_bridges": bridge_records,
        "target_allocations": dev_allocations,
        "created_at": datetime.now().isoformat(),
        "status": "active"
    }
    
    if "development_funds" not in mock_db:
        mock_db["development_funds"] = []
    mock_db["development_funds"].append(fund_record)
    
    return {
        "success": True,
        "fund_id": fund_id,
        "fund_name": fund_strategy["name"],
        "total_development_capital": total_bridged_usd,
        "allocations": dev_allocations,
        "message": f"Development fund created with ${total_bridged_usd:,.0f} in capital",
        "ready_for_withdrawal": True
    }

@app.get("/api/withdrawals/history")
async def get_withdrawal_history():
    """Get withdrawal history for external wallets"""
    
    return {
        "external_withdrawals": mock_db.get("external_withdrawals", []),
        "development_funds": mock_db.get("development_funds", []),
        "preset_withdrawals": mock_db.get("preset_withdrawals", []),
        "total_withdrawn_usd": sum(w.get("usd_value", 0) for w in mock_db.get("external_withdrawals", []))
    }

# CDT Bridge and IOU System
class CDTBridgeRequest(BaseModel):
    source_token: str
    amount: float
    cdt_target_amount: float
    user_wallet: str
    bridge_type: str = "direct"  # "direct" or "iou"

@app.get("/api/cdt/pricing")
async def get_cdt_pricing():
    """Get current CDT pricing and purchase options"""
    
    cdt_price = 0.10  # $0.10 per CDT
    
    # Calculate how much CDT you can buy with each token
    purchase_options = {}
    
    for token_symbol, token_info in YOUR_PORTFOLIO.items():
        if token_info["your_balance"] > 0 and token_symbol != "CDT":
            max_usd_value = token_info["your_balance"] * token_info["current_price"]
            max_cdt_amount = max_usd_value / cdt_price
            
            purchase_options[token_symbol] = {
                "available_balance": token_info["your_balance"],
                "max_usd_value": max_usd_value,
                "max_cdt_amount": max_cdt_amount,
                "exchange_rate": f"1 {token_symbol} = {token_info['current_price'] / cdt_price:.2f} CDT",
                "liquidity_type": "high" if token_symbol in ["USDC", "DOGE", "TRX"] else "medium" if token_symbol == "CRT" else "low"
            }
    
    return {
        "cdt_price_usd": cdt_price,
        "purchase_options": purchase_options,
        "recommended_sources": {
            "liquid_assets": ["USDC", "DOGE", "TRX"],
            "illiquid_assets": ["CRT", "T52M"],
            "bridge_methods": {
                "direct": "Instant conversion for liquid assets",
                "iou": "IOU bridge for illiquid assets - immediate CDT access with future repayment"
            }
        },
        "total_purchase_power_cdt": sum(opt["max_cdt_amount"] for opt in purchase_options.values())
    }

@app.post("/api/cdt/bridge")
async def bridge_to_cdt(request: CDTBridgeRequest):
    """Bridge tokens to CDT with IOU support for illiquid assets"""
    
    # Validate source token
    if request.source_token not in YOUR_PORTFOLIO:
        raise HTTPException(status_code=400, detail="Source token not available")
    
    source_info = YOUR_PORTFOLIO[request.source_token]
    
    # Check balance
    if request.amount > source_info["your_balance"]:
        raise HTTPException(
            status_code=400,
            detail=f"Insufficient balance. Available: {source_info['your_balance']:,} {request.source_token}"
        )
    
    # Calculate CDT amount
    source_usd_value = request.amount * source_info["current_price"]
    cdt_price = 0.10
    cdt_amount = source_usd_value / cdt_price
    
    # Determine bridge method
    illiquid_tokens = ["CRT", "T52M"]
    is_illiquid = request.source_token in illiquid_tokens
    
    bridge_method = "iou" if is_illiquid and request.bridge_type == "iou" else "direct"
    
    # Create bridge record
    bridge_id = f"cdt_bridge_{len(mock_db.get('cdt_bridges', []))}"
    
    bridge_record = {
        "bridge_id": bridge_id,
        "source_token": request.source_token,
        "source_amount": request.amount,
        "source_usd_value": source_usd_value,
        "cdt_amount": cdt_amount,
        "bridge_method": bridge_method,
        "user_wallet": request.user_wallet,
        "status": "completed",
        "timestamp": datetime.now().isoformat()
    }
    
    # Handle IOU bridge for illiquid assets
    if bridge_method == "iou":
        iou_record = {
            "iou_id": f"iou_{bridge_id}",
            "debtor_wallet": request.user_wallet,
            "debt_token": request.source_token,
            "debt_amount": request.amount,
            "debt_usd_value": source_usd_value,
            "collateral_cdt": cdt_amount,
            "status": "active",
            "created_at": datetime.now().isoformat(),
            "repayment_terms": f"Repay {request.amount:,} {request.source_token} or equivalent USD value",
            "maturity": "flexible - repay when you want"
        }
        
        bridge_record["iou_details"] = iou_record
        
        if "iou_records" not in mock_db:
            mock_db["iou_records"] = []
        mock_db["iou_records"].append(iou_record)
        
        # Don't deduct source balance for IOU (it's collateralized)
        bridge_record["balance_change"] = "collateralized - no deduction"
    else:
        # Direct bridge - deduct source balance
        YOUR_PORTFOLIO[request.source_token]["your_balance"] -= request.amount
        bridge_record["balance_change"] = f"deducted {request.amount} {request.source_token}"
    
    # Add CDT to portfolio
    YOUR_PORTFOLIO["CDT"]["your_balance"] += cdt_amount
    
    # Store bridge record
    if "cdt_bridges" not in mock_db:
        mock_db["cdt_bridges"] = []
    mock_db["cdt_bridges"].append(bridge_record)
    
    return {
        "success": True,
        "bridge_id": bridge_id,
        "method": bridge_method,
        "message": f"Successfully bridged {request.amount:,} {request.source_token} → {cdt_amount:,.2f} CDT",
        "cdt_received": cdt_amount,
        "cdt_total_balance": YOUR_PORTFOLIO["CDT"]["your_balance"],
        "bridge_details": bridge_record,
        "iou_active": bridge_method == "iou"
    }

@app.get("/api/cdt/iou-status")
async def get_iou_status():
    """Get status of all IOU bridges"""
    
    iou_records = mock_db.get("iou_records", [])
    
    active_ious = [iou for iou in iou_records if iou["status"] == "active"]
    total_debt_usd = sum(iou["debt_usd_value"] for iou in active_ious)
    total_collateral_cdt = sum(iou["collateral_cdt"] for iou in active_ious)
    
    return {
        "active_ious": active_ious,
        "summary": {
            "total_active_ious": len(active_ious),
            "total_debt_usd": total_debt_usd,
            "total_collateral_cdt": total_collateral_cdt,
            "debt_by_token": {}
        },
        "repayment_options": {
            "full_repayment": "Return original tokens to close IOU",
            "partial_repayment": "Reduce debt amount",
            "refinance": "Convert to different collateral",
            "liquidation": "Surrender CDT to close debt (penalty may apply)"
        }
    }

@app.post("/api/cdt/iou-repay")
async def repay_iou(iou_id: str, repayment_type: str = "full"):
    """Repay IOU bridge debt"""
    
    iou_records = mock_db.get("iou_records", [])
    
    # Find IOU
    iou_record = None
    for iou in iou_records:
        if iou["iou_id"] == iou_id and iou["status"] == "active":
            iou_record = iou
            break
    
    if not iou_record:
        raise HTTPException(status_code=404, detail="IOU record not found or already closed")
    
    debt_token = iou_record["debt_token"]
    debt_amount = iou_record["debt_amount"]
    collateral_cdt = iou_record["collateral_cdt"]
    
    if repayment_type == "full":
        # Check if user has enough of debt token to repay
        if YOUR_PORTFOLIO[debt_token]["your_balance"] >= debt_amount:
            # Deduct debt token
            YOUR_PORTFOLIO[debt_token]["your_balance"] -= debt_amount
            
            # Close IOU
            iou_record["status"] = "repaid"
            iou_record["repaid_at"] = datetime.now().isoformat()
            
            return {
                "success": True,
                "message": f"IOU repaid successfully with {debt_amount:,} {debt_token}",
                "iou_id": iou_id,
                "repaid_amount": debt_amount,
                "repaid_token": debt_token,
                "cdt_retained": collateral_cdt
            }
        else:
            raise HTTPException(
                status_code=400, 
                detail=f"Insufficient {debt_token} balance for repayment. Need: {debt_amount:,}, Have: {YOUR_PORTFOLIO[debt_token]['your_balance']:,}"
            )
    
    elif repayment_type == "liquidation":
        # Surrender CDT to close debt (with penalty)
        penalty_rate = 0.10  # 10% penalty
        cdt_to_surrender = collateral_cdt * (1 + penalty_rate)
        
        if YOUR_PORTFOLIO["CDT"]["your_balance"] >= cdt_to_surrender:
            # Deduct CDT with penalty
            YOUR_PORTFOLIO["CDT"]["your_balance"] -= cdt_to_surrender
            
            # Close IOU
            iou_record["status"] = "liquidated"
            iou_record["liquidated_at"] = datetime.now().isoformat()
            iou_record["penalty_applied"] = penalty_rate
            
            return {
                "success": True,
                "message": f"IOU liquidated - surrendered {cdt_to_surrender:,.2f} CDT ({penalty_rate*100}% penalty applied)",
                "iou_id": iou_id,
                "surrendered_cdt": cdt_to_surrender,
                "penalty_applied": f"{penalty_rate*100}%",
                "debt_cleared": True
            }
        else:
            raise HTTPException(
                status_code=400,
                detail=f"Insufficient CDT for liquidation. Need: {cdt_to_surrender:,.2f} CDT, Have: {YOUR_PORTFOLIO['CDT']['your_balance']:,.2f} CDT"
            )

@app.get("/api/games")
async def get_games():
    """Get available casino games"""
    return {
        "games": [
            {"id": "blackjack", "name": "🃏 Blackjack", "min_bet": 10, "max_bet": 10000},
            {"id": "roulette", "name": "🎰 Roulette", "min_bet": 5, "max_bet": 5000},
            {"id": "slots", "name": "🎲 Slots", "min_bet": 1, "max_bet": 1000}
        ],
        "supported_tokens": list(YOUR_PORTFOLIO.keys())
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)