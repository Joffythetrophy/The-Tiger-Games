# 🐅 TIGER BANK CASINO 🏦

**A casino that saves your losses like a piggy bank!**

Tiger Bank Casino combines the thrill of gambling with smart financial planning. When you lose, we automatically split your losses 50/50:
- **50% → Personal Piggy Bank** (Safe savings)
- **50% → Investment Pools** (DeFi earning potential)

## 🎯 Features

- **🎰 Real Casino Games**: Blackjack, Roulette, Slots
- **🐷 Automatic Savings**: 50% of losses saved safely
- **🏊‍♂️ Pool Investment**: 50% of losses earning yield
- **💰 Protected Funds**: Savings can't be lost gambling
- **📱 Mobile Friendly**: Play anywhere, anytime

## 🚀 Quick Deploy

This app auto-deploys to Render with the included `render.yaml` configuration:

1. **Fork this repository**
2. **Connect to [Render.com](https://render.com)**
3. **Auto-deployment starts!** ✨

## 📁 Project Structure

```
TIGERBANCKCASINO/
├── backend/          # FastAPI server with casino logic
├── frontend/         # React casino interface
├── render.yaml       # Deployment configuration
└── README.md         # This file
```

## 🎮 How to Play

1. **Start with $1,000 balance**
2. **Choose your game** (Blackjack, Roulette, Slots)
3. **Place your bet**
4. **Win or lose smartly**:
   - **Win**: Get 80% profit
   - **Lose**: 50% saved, 50% invested

## 🏦 The Tiger Bank Difference

Traditional casinos take 100% of your losses. Tiger Bank Casino:
- ✅ **Saves 50%** in your personal piggy bank
- ✅ **Invests 50%** in yield-generating pools  
- ✅ **Protects your future** while you have fun
- ✅ **Turns losses into assets**

## 🛠️ Tech Stack

- **Backend**: FastAPI + Python
- **Frontend**: React + JavaScript
- **Database**: MongoDB (production ready)
- **Deployment**: Render (auto-scaling)

## 📞 Support

Having issues? Check the deployment logs in your Render dashboard or create an issue in this repository.

---

**Start building your financial future while having fun!** 🎰💪